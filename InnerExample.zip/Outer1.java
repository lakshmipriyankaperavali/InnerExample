package com.InnerExample;

public class Outer1 {
	int x=100;
	class Inner{
		int y=200;
		void show(){
			System.out.println(x+" "+y);
			
		}
	}
	public	void display(){
			Inner n=new Inner();
			n.show();
		}
	public static void main(String args[]){
	Outer1 obj=new Outer1();
	obj.display();
}
}
