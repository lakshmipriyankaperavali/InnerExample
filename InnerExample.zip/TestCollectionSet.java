package com.InnerExample;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCollectionSet {
public static void main(String args[])
{
ApplicationContext con=new ClassPathXmlApplicationContext("bean1.xml");
Object o=con.getBean("lib");
LibrarySet library=(LibrarySet) o;
System.out.println(library);
}
}

