package com.InnerExample;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.parsing.ParseState.Entry;



public class Question {
	private int id;
	private String name;
	private Map<String,String>answers;
	public Question(){
	}
	public Question(int id,String name,Map<String,String> answers){
		super();
		this.id=id;
		this.name=name;
		this.answers=answers;
	}
	public void displayInfo(){
		System.out.println("question id is:" +id);
		System.out.println("question name is:" +name);
		System.out.println("Answers.....");
		Set<java.util.Map.Entry<String, String>> set=answers.entrySet();
		Iterator<java.util.Map.Entry<String, String>> itr=set.iterator();
		while(itr.hasNext()){
			java.util.Map.Entry<String, String> entry=itr.next();
			System.out.println("Answers:" +entry.getKey()+ "Posted by:" +entry.getValue());
		}
	}

}
