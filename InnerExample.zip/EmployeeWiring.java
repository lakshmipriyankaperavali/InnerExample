package com.InnerExample;

public class EmployeeWiring {
	int salary;
	private Address addr;
	
	public EmployeeWiring(){}
	public EmployeeWiring(Address addr){
		this.addr=addr;
	}
	
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "EmployeeWiring [salary=" + salary + ", addr=" + addr + "]";
	}
	
	
}
