package com.InnerExample;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
  public class TestWiring1 {
     	public static void main(String args[])
     	{
		Resource r= new ClassPathResource("applicationContext4.xml");
		BeanFactory factory=new XmlBeanFactory(r);
		EmployeeWiring1 obj=(EmployeeWiring1)factory.getBean("id2");
		System.out.println(obj.toString());
		}
}
