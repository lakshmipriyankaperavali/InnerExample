package com.InnerExample;
interface Age{
	int x=21;
	void getAge();
}
public class AnonymousDemo {
public static void main(String args[]){
	//Person p=new Person();
	//p.getAge();
	Age obj=new Age(){
		public void getAge(){
			System.out.println("Age is "+x);
		}
	};
		obj.getAge();
	}
}
