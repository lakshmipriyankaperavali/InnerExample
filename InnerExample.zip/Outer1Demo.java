package com.InnerExample;

import com.InnerExample.Outer1.Inner;

public class Outer1Demo {
static	int x=100;
	static class Inner{
		int y=200;
	public	void show(){
			System.out.println(x+" "+y);
			
		}
	}
	
	public static void main(String args[]){
	Outer1Demo.Inner obj=new Outer1Demo.Inner();
	obj.show();
}

}
	