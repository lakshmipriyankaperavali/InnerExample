package com.InnerExample;

public class Address {
	private int salary;
	private String loc;
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	@Override
	public String toString() {
		return "Address [salary=" + salary + ", loc=" + loc + "]";
	}
	public Address(int salary, String loc) {
		super();
		this.salary = salary;
		this.loc = loc;
	}
	

}
