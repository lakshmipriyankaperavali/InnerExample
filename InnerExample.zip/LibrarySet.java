package com.InnerExample;

import java.util.Set;

public class LibrarySet {
	private int id;
	private String name;
	private Set<String> books;
	
	public LibrarySet(int id,String name,Set<String>books){
		this.id=id;
		this.name=name;
		this.books=books;
	}

	@Override
	public String toString() {
		return " id is=" + id + "Library name=" + name + "Book Detils"+ books;
	}

	
	}
