package com.InnerExample;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCollectionList {
public static void main(String args[])
{
ApplicationContext con=new ClassPathXmlApplicationContext("bean.xml");
Object o=con.getBean("lib");
LibraryList library=(LibraryList) o;
System.out.println(library);
}
}

